# MediaPicker Pro - Local Media Culling & Slideshow Studio

High-speed local photo and video reviewer, fullscreen slideshow, and gallery culling studio. Completely runs in your browser with 100% offline security and zero external uploads.

## Quick Start (macOS / Linux)

1. Double-click `install.command` to install dependencies (one-time setup).
2. Double-click `start.command` to launch the app. It will open `http://localhost:3000` automatically!

## Manual Terminal Start

```bash
# 1. Install dependencies
npm install

# 2. Start offline development server
npm run dev

# Or build optimized production bundle
npm run build
npm start
```

## Key Shortcuts

- **Spacebar / Left-Click**: Select / Deselect current photo or video
- **Right Arrow**: Next slide (navigates to gallery on completion)
- **Left Arrow**: Previous slide
- **Enter / P**: Play / Pause slideshow (with animated center splash HUD)
- **M**: Toggle Sound Mute / Unmute
- **Cmd + C / Ctrl + C**: Copy all selected paths to clipboard
- **Cmd + Z / Ctrl + Z**: Undo last selection
- **Backspace**: Switch to Gallery view (from slideshow) or return to Dashboard (from gallery)
- **F**: Toggle OS Fullscreen
- **Esc**: Exit slideshow / close any active modal
- **?**: Open Keyboard & Mouse Shortcuts cheatsheet
