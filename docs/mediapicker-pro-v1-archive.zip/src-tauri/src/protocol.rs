use std::fs::File;
use std::io::{Read, Seek, SeekFrom};
use std::path::PathBuf;
use tauri::http::{header::*, status::StatusCode, Request, Response, ResponseBuilder};

pub fn handle_media_protocol(
    _app: &tauri::AppHandle,
    request: &Request<Vec<u8>>,
) -> Result<Response<Vec<u8>>, Box<dyn std::error::Error>> {
    let uri = request.uri().to_string();
    
    // Strip scheme "mediapicker://"
    let raw_path = uri.trim_start_matches("mediapicker://");
    
    // Decode percent-encoded path
    let decoded_path = percent_encoding::percent_decode_str(raw_path)
        .decode_utf8_lossy()
        .to_string();
    
    let path = PathBuf::from(&decoded_path);
    if !path.exists() || !path.is_file() {
        return Ok(ResponseBuilder::new()
            .status(StatusCode::NOT_FOUND)
            .body(b"File Not Found".to_vec())?);
    }

    let mut file = File::open(&path)?;
    let metadata = file.metadata()?;
    let total_len = metadata.len();

    let ext = path
        .extension()
        .and_then(|e| e.to_str())
        .unwrap_or("")
        .to_lowercase();

    let content_type = match ext.as_str() {
        "jpg" | "jpeg" => "image/jpeg",
        "png" => "image/png",
        "webp" => "image/webp",
        "gif" => "image/gif",
        "svg" => "image/svg+xml",
        "bmp" => "image/bmp",
        "avif" => "image/avif",
        "heic" | "heif" => "image/heic",
        "mp4" => "video/mp4",
        "webm" => "video/webm",
        "mov" => "video/quicktime",
        "m4v" => "video/x-m4v",
        "mkv" => "video/x-matroska",
        _ => "application/octet-stream",
    };

    // Range request handling for video streaming
    if let Some(range_header) = request.headers().get(RANGE) {
        if let Ok(range_str) = range_header.to_str() {
            if range_str.starts_with("bytes=") {
                let range = &range_str[6..];
                let parts: Vec<&str> = range.split('-').collect();
                let start: u64 = parts[0].parse().unwrap_or(0);
                let end: u64 = if parts.len() > 1 && !parts[1].is_empty() {
                    parts[1].parse().unwrap_or(total_len - 1)
                } else {
                    total_len - 1
                };

                let length = end.saturating_sub(start) + 1;
                file.seek(SeekFrom::Start(start))?;
                let mut buffer = vec![0u8; length as usize];
                file.read_exact(&mut buffer)?;

                return Ok(ResponseBuilder::new()
                    .status(StatusCode::PARTIAL_CONTENT)
                    .header(CONTENT_TYPE, content_type)
                    .header(CONTENT_LENGTH, length.to_string())
                    .header(
                        CONTENT_RANGE,
                        format!("bytes {}-{}/{}", start, end, total_len),
                    )
                    .header(ACCEPT_RANGES, "bytes")
                    .body(buffer)?);
            }
        }
    }

    // Default full content
    let mut buffer = Vec::new();
    file.read_to_end(&mut buffer)?;

    Ok(ResponseBuilder::new()
        .status(StatusCode::OK)
        .header(CONTENT_TYPE, content_type)
        .header(CONTENT_LENGTH, total_len.to_string())
        .header(ACCEPT_RANGES, "bytes")
        .body(buffer)?)
}
