'use client';

import React, { useState, useMemo, useCallback, useEffect } from 'react';
import { FolderProject, MediaFileItem, AppSettings, GallerySortOption } from '@/lib/types';
import { naturalSortCompare } from '@/lib/file-scanner';
import { formatClipboardPaths } from '@/lib/zip-exporter';
import {
  Search,
  Play,
  CheckCircle2,
  Eye,
  AlertCircle,
  Film,
  Image as ImageIcon,
  ChevronLeft,
  ChevronRight,
  Volume2,
  VolumeX,
  X,
  Archive,
  ArrowUpDown,
  Filter,
} from 'lucide-react';

interface GalleryViewProps {
  project: FolderProject;
  settings: AppSettings;
  onUpdateSettings: (newSettings: Partial<AppSettings>) => void;
  onUpdateProject: (updatedProject: FolderProject) => void;
  onStartSlideshow: (startIndex: number) => void;
  onClose: () => void;
  onOpenActionModal: () => void;
  onShowToast: (message: string) => void;
}

export function GalleryView({
  project,
  settings,
  onUpdateSettings,
  onUpdateProject,
  onStartSlideshow,
  onClose,
  onOpenActionModal,
  onShowToast,
}: GalleryViewProps) {
  const [currentPage, setCurrentPage] = useState<number>(1);
  const [searchQuery, setSearchQuery] = useState<string>('');
  const [filterType, setFilterType] = useState<'all' | 'selected' | 'unselected' | 'images' | 'videos'>('all');
  const [sortOption, setSortOption] = useState<GallerySortOption>('folder_name');
  const [hoveredVideoId, setHoveredVideoId] = useState<string | null>(null);
  const [revealedIds, setRevealedIds] = useState<Set<string>>(new Set());

  const itemsPerPage = settings.itemsPerPage || 1000;

  // Filter items by project active subfolders first
  const baseItems = useMemo(() => {
    return project.items.filter((item) => {
      if (!item.subfolder) {
        return project.includeRootFiles !== false;
      }
      return project.enabledSubfolders?.includes(item.subfolder) ?? true;
    });
  }, [project.items, project.enabledSubfolders, project.includeRootFiles]);

  // Generate or get objectUrl for media
  const getMediaUrl = useCallback((item: MediaFileItem): string => {
    if (item.objectUrl) return item.objectUrl;
    if (item.file) {
      item.objectUrl = URL.createObjectURL(item.file);
      return item.objectUrl;
    }
    return '';
  }, []);

  // Filtered and Sorted items
  const processedItems = useMemo(() => {
    const filtered = baseItems.filter((item) => {
      if (searchQuery.trim() && !item.name.toLowerCase().includes(searchQuery.toLowerCase().trim())) {
        return false;
      }
      if (filterType === 'selected') return item.selected;
      if (filterType === 'unselected') return !item.selected;
      if (filterType === 'images') return item.type === 'image';
      if (filterType === 'videos') return item.type === 'video';
      return true;
    });

    // Sorting
    return filtered.sort((a, b) => {
      switch (sortOption) {
        case 'name_asc':
          return naturalSortCompare(a.name, b.name);
        case 'name_desc':
          return naturalSortCompare(b.name, a.name);
        case 'folder_name':
          return naturalSortCompare(a.relativePath, b.relativePath);
        case 'date_newest':
          return (b.lastModified || 0) - (a.lastModified || 0);
        case 'date_oldest':
          return (a.lastModified || 0) - (b.lastModified || 0);
        case 'size_desc':
          return b.size - a.size;
        case 'size_asc':
          return a.size - b.size;
        case 'type':
          return a.type === b.type ? naturalSortCompare(a.name, b.name) : a.type === 'image' ? -1 : 1;
        default:
          return naturalSortCompare(a.relativePath, b.relativePath);
      }
    });
  }, [baseItems, searchQuery, filterType, sortOption]);

  const totalPages = Math.max(1, Math.ceil(processedItems.length / itemsPerPage));

  // Current page slice
  const pageItems = useMemo(() => {
    const start = (currentPage - 1) * itemsPerPage;
    return processedItems.slice(start, start + itemsPerPage);
  }, [processedItems, currentPage, itemsPerPage]);

  // Toggle selection
  const toggleSelect = useCallback(
    (id: string) => {
      const newItems = project.items.map((item) => {
        if (item.id === id) {
          return { ...item, selected: !item.selected };
        }
        return item;
      });
      const selectedCount = newItems.filter((i) => i.selected).length;
      onUpdateProject({
        ...project,
        items: newItems,
        selectedCount,
      });
    },
    [project, onUpdateProject]
  );

  // Manual reveal of >5MB or >100MB files
  const revealMedia = (id: string, e: React.MouseEvent) => {
    e.stopPropagation();
    setRevealedIds((prev) => {
      const next = new Set(prev);
      next.add(id);
      return next;
    });
  };

  // Copy selected paths to clipboard
  const handleCopyClipboard = useCallback(async () => {
    const selected = project.items.filter((i) => i.selected);
    if (selected.length === 0) {
      onShowToast('No media selected yet.');
      return;
    }
    const text = formatClipboardPaths(selected, settings.clipboardFormat);
    try {
      await navigator.clipboard.writeText(text);
      onShowToast(`Copied ${selected.length} path(s) to clipboard.`);
    } catch {
      onShowToast('Clipboard access was denied by browser.');
    }
  }, [project.items, settings.clipboardFormat, onShowToast]);

  // Keyboard shortcuts in gallery
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      const activeElem = document.activeElement;
      const isInput = activeElem?.tagName === 'INPUT' || activeElem?.tagName === 'TEXTAREA';

      if ((e.metaKey || e.ctrlKey) && e.key.toLowerCase() === 'c') {
        e.preventDefault();
        handleCopyClipboard();
        return;
      }
      if (e.key === 'Backspace' && !isInput) {
        e.preventDefault();
        onClose(); // Backspace returns to Dashboard from Gallery
        return;
      }
      if (e.key === 'Escape') {
        e.preventDefault();
        onClose();
        return;
      }
    };
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [handleCopyClipboard, onClose]);

  const isOrange = settings.neonAccent === 'orange';
  const selectedCount = project.items.filter((i) => i.selected).length;

  return (
    <div className="min-h-screen bg-slate-50 dark:bg-slate-950 text-slate-900 dark:text-slate-100 flex flex-col font-sans transition-colors duration-200">
      {/* 1. STICKY TOP TOOLBAR */}
      <div className="sticky top-0 z-30 bg-white/90 dark:bg-slate-950/90 backdrop-blur-md border-b border-slate-200 dark:border-slate-800 px-4 sm:px-6 py-3 transition-colors">
        <div className="max-w-7xl mx-auto flex flex-col md:flex-row items-center justify-between gap-3">
          {/* Left: Project title & Back button */}
          <div className="flex items-center gap-3 w-full md:w-auto justify-between md:justify-start">
            <button
              onClick={onClose}
              className="p-1.5 rounded-lg border border-slate-300 dark:border-slate-800 bg-slate-100 dark:bg-slate-900 text-slate-700 dark:text-slate-300 hover:text-slate-900 dark:hover:text-white transition-colors"
              title="Return to Dashboard (Backspace / Esc)"
            >
              <X className="w-4 h-4" />
            </button>
            <div className="text-left">
              <h1 className="text-sm font-bold text-slate-900 dark:text-white truncate max-w-xs">{project.name}</h1>
              <p className="text-[11px] text-slate-500 dark:text-slate-400">
                Grid Gallery · {processedItems.length} media
              </p>
            </div>
          </div>

          {/* Center: Search, Filters, and Sorting Dropdown */}
          <div className="flex items-center gap-2 w-full md:w-auto justify-center flex-wrap">
            {/* Search Input */}
            <div className="relative min-w-[140px] sm:w-44">
              <input
                type="text"
                placeholder="Search filenames..."
                value={searchQuery}
                onChange={(e) => {
                  setSearchQuery(e.target.value);
                  setCurrentPage(1);
                }}
                className="w-full pl-8 pr-3 py-1.5 bg-slate-100 dark:bg-slate-900 border border-slate-300 dark:border-slate-800 rounded-lg text-xs text-slate-900 dark:text-white placeholder-slate-400 focus:outline-none focus:border-orange-500"
              />
              <Search className="w-3.5 h-3.5 text-slate-400 absolute left-2.5 top-2.5" />
            </div>

            {/* Filter Tabs */}
            <div className="flex items-center gap-1 p-1 bg-slate-100 dark:bg-slate-900 border border-slate-300 dark:border-slate-800 rounded-lg text-xs">
              {[
                { id: 'all', label: 'All' },
                { id: 'selected', label: `Selected (${selectedCount})` },
                { id: 'images', label: 'Photos' },
                { id: 'videos', label: 'Videos' },
              ].map((tab) => (
                <button
                  key={tab.id}
                  onClick={() => {
                    setFilterType(tab.id as any);
                    setCurrentPage(1);
                  }}
                  className={`px-2.5 py-1 rounded-md text-[11px] font-medium transition-colors ${
                    filterType === tab.id
                      ? isOrange
                        ? 'bg-orange-500 text-white shadow-sm'
                        : 'bg-emerald-500 text-white shadow-sm'
                      : 'text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-slate-200'
                  }`}
                >
                  {tab.label}
                </button>
              ))}
            </div>

            {/* Sort Dropdown */}
            <div className="flex items-center gap-1 bg-slate-100 dark:bg-slate-900 border border-slate-300 dark:border-slate-800 rounded-lg px-2 py-1 text-xs text-slate-700 dark:text-slate-300">
              <ArrowUpDown className="w-3 h-3 text-slate-400" />
              <select
                value={sortOption}
                onChange={(e) => setSortOption(e.target.value as GallerySortOption)}
                className="bg-transparent border-none text-xs text-slate-800 dark:text-slate-200 focus:outline-none cursor-pointer pr-1"
              >
                <option value="folder_name" className="bg-white dark:bg-slate-900">Folder & Name</option>
                <option value="name_asc" className="bg-white dark:bg-slate-900">Name (A-Z)</option>
                <option value="name_desc" className="bg-white dark:bg-slate-900">Name (Z-A)</option>
                <option value="date_newest" className="bg-white dark:bg-slate-900">Date Modified (Newest)</option>
                <option value="date_oldest" className="bg-white dark:bg-slate-900">Date Modified (Oldest)</option>
                <option value="size_desc" className="bg-white dark:bg-slate-900">Size (Largest)</option>
                <option value="size_asc" className="bg-white dark:bg-slate-900">Size (Smallest)</option>
                <option value="type" className="bg-white dark:bg-slate-900">Media Type</option>
              </select>
            </div>
          </div>

          {/* Right: Actions */}
          <div className="flex items-center gap-2">
            {/* Sound toggle */}
            <button
              onClick={() => onUpdateSettings({ globalMuted: !settings.globalMuted })}
              className="p-1.5 rounded-lg border border-slate-300 dark:border-slate-800 bg-slate-100 dark:bg-slate-900 text-slate-700 dark:text-slate-300 hover:text-slate-900 dark:hover:text-white transition-colors"
              title={settings.globalMuted ? 'Audio Muted (M)' : 'Audio Active (M)'}
            >
              {settings.globalMuted ? <VolumeX className="w-4 h-4 text-slate-400" /> : <Volume2 className="w-4 h-4 text-emerald-500" />}
            </button>

            {/* Quick Actions modal */}
            <button
              onClick={onOpenActionModal}
              className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-medium border border-slate-300 dark:border-slate-800 bg-slate-100 dark:bg-slate-900 text-slate-800 dark:text-slate-200 hover:text-slate-900 dark:hover:text-white transition-colors"
              title="Export ZIP and Batch Actions"
            >
              <Archive className="w-3.5 h-3.5 text-orange-500" />
              <span>Actions & Export</span>
            </button>

            {/* Start Slideshow from beginning */}
            <button
              onClick={() => onStartSlideshow(0)}
              className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-medium text-white transition-all shadow-sm ${
                isOrange
                  ? 'bg-orange-600 hover:bg-orange-500 shadow-orange-600/30'
                  : 'bg-emerald-600 hover:bg-emerald-500 shadow-emerald-600/30'
              }`}
            >
              <Play className="w-3.5 h-3.5" />
              <span>Play Slideshow</span>
            </button>
          </div>
        </div>

        {/* Pagination Bar (if multiple pages of 1000 items) */}
        {totalPages > 1 && (
          <div className="mt-2.5 pt-2 border-t border-slate-200 dark:border-slate-800/80 flex items-center justify-between text-xs text-slate-500 dark:text-slate-400 max-w-7xl mx-auto">
            <span>
              Showing items {(currentPage - 1) * itemsPerPage + 1} to{' '}
              {Math.min(currentPage * itemsPerPage, processedItems.length)} of {processedItems.length}
            </span>
            <div className="flex items-center gap-2">
              <button
                disabled={currentPage <= 1}
                onClick={() => setCurrentPage((p) => p - 1)}
                className="p-1 rounded bg-slate-100 dark:bg-slate-900 border border-slate-300 dark:border-slate-800 disabled:opacity-40"
              >
                <ChevronLeft className="w-4 h-4" />
              </button>
              <span className="font-mono tabular-nums text-slate-900 dark:text-white">
                Page {currentPage} of {totalPages}
              </span>
              <button
                disabled={currentPage >= totalPages}
                onClick={() => setCurrentPage((p) => p + 1)}
                className="p-1 rounded bg-slate-100 dark:bg-slate-900 border border-slate-300 dark:border-slate-800 disabled:opacity-40"
              >
                <ChevronRight className="w-4 h-4" />
              </button>
            </div>
          </div>
        )}
      </div>

      {/* 2. MEDIA GRID */}
      <div className="flex-1 max-w-7xl mx-auto w-full p-4 sm:p-6">
        {pageItems.length === 0 ? (
          <div className="py-24 text-center space-y-3">
            <AlertCircle className="w-12 h-12 text-slate-400 dark:text-slate-600 mx-auto" />
            <p className="text-sm text-slate-600 dark:text-slate-300">No media found matching current filter.</p>
          </div>
        ) : (
          <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5 xl:grid-cols-6 gap-3 sm:gap-4">
            {pageItems.map((item) => {
              const isSelected = item.selected;
              const sizeMB = item.size / (1024 * 1024);
              const limitMB = item.type === 'image' ? (settings.imageSizeLimitMB || 5) : (settings.videoSizeLimitMB || 100);
              const isHeavy = sizeMB > limitMB;
              const isRevealed = revealedIds.has(item.id) || !isHeavy;

              const glowClass = isSelected
                ? isOrange
                  ? 'ring-2 ring-orange-500 shadow-[0_0_20px_rgba(249,115,22,0.6)] border-orange-500'
                  : 'ring-2 ring-emerald-500 shadow-[0_0_20px_rgba(16,185,129,0.6)] border-emerald-500'
                : 'border-slate-200 dark:border-slate-800 hover:border-slate-400 dark:hover:border-slate-700';

              return (
                <div
                  key={item.id}
                  onClick={() => toggleSelect(item.id)}
                  onMouseEnter={() => {
                    if (item.type === 'video') setHoveredVideoId(item.id);
                  }}
                  onMouseLeave={() => {
                    if (item.type === 'video') setHoveredVideoId(null);
                  }}
                  className={`group relative aspect-square rounded-xl overflow-hidden bg-slate-200 dark:bg-slate-900 border transition-all cursor-pointer flex flex-col justify-between ${glowClass}`}
                >
                  {/* Media Content or Heavy File Badge */}
                  {!isRevealed ? (
                    <div className="w-full h-full flex flex-col items-center justify-center p-3 text-center bg-slate-100 dark:bg-slate-900/90 text-slate-700 dark:text-slate-300 space-y-2">
                      <div className="w-8 h-8 rounded-full bg-amber-500/10 border border-amber-500/30 flex items-center justify-center text-amber-500">
                        {item.type === 'video' ? <Film className="w-4 h-4" /> : <ImageIcon className="w-4 h-4" />}
                      </div>
                      <span className="text-[11px] font-semibold text-amber-600 dark:text-amber-400">
                        Size: {sizeMB.toFixed(1)} MB
                      </span>
                      <p className="text-[10px] text-slate-500 dark:text-slate-400">
                        {item.type === 'image' ? `Over ${settings.imageSizeLimitMB} MB limit` : `Over ${settings.videoSizeLimitMB} MB limit`}
                      </p>
                      <button
                        onClick={(e) => revealMedia(item.id, e)}
                        className="px-2.5 py-1 rounded bg-slate-200 dark:bg-slate-800 hover:bg-slate-300 dark:hover:bg-slate-700 text-[11px] text-slate-900 dark:text-white flex items-center gap-1 transition-colors border border-slate-300 dark:border-slate-700 shadow-sm"
                        title="Load and reveal media"
                      >
                        <Eye className="w-3 h-3 text-sky-500" />
                        <span>Reveal</span>
                      </button>
                    </div>
                  ) : item.type === 'image' ? (
                    // eslint-disable-next-line @next/next/no-img-element
                    <img
                      src={getMediaUrl(item)}
                      alt={item.name}
                      loading="lazy"
                      referrerPolicy="no-referrer"
                      className="w-full h-full object-cover transition-transform duration-300 group-hover:scale-105"
                    />
                  ) : (
                    <video
                      src={getMediaUrl(item)}
                      muted={settings.globalMuted}
                      loop
                      playsInline
                      autoPlay={hoveredVideoId === item.id}
                      className="w-full h-full object-cover"
                    />
                  )}

                  {/* Top Badges */}
                  <div className="absolute top-2 left-2 right-2 flex items-center justify-between pointer-events-none z-10">
                    <div className="p-1 rounded bg-black/60 backdrop-blur-sm text-slate-200">
                      {item.type === 'video' ? <Film className="w-3 h-3" /> : <ImageIcon className="w-3 h-3" />}
                    </div>

                    {isSelected && (
                      <div
                        className={`p-1 rounded-full text-white shadow-md animate-in zoom-in-75 ${
                          isOrange ? 'bg-orange-500 shadow-orange-500/50' : 'bg-emerald-500 shadow-emerald-500/50'
                        }`}
                      >
                        <CheckCircle2 className="w-3.5 h-3.5" />
                      </div>
                    )}
                  </div>

                  {/* Play Slideshow from this specific item */}
                  <div className="absolute inset-0 bg-black/40 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center gap-2 pointer-events-auto">
                    <button
                      onClick={(e) => {
                        e.stopPropagation();
                        const originalIndex = baseItems.findIndex((i) => i.id === item.id);
                        onStartSlideshow(originalIndex >= 0 ? originalIndex : 0);
                      }}
                      className="p-2.5 rounded-full bg-white/90 hover:bg-white text-slate-900 shadow-xl transition-transform hover:scale-110"
                      title="Play slideshow starting from this slide"
                    >
                      <Play className="w-4 h-4 fill-slate-900" />
                    </button>
                  </div>

                  {/* Bottom Filename Overlay */}
                  <div className="absolute bottom-0 inset-x-0 bg-gradient-to-t from-black/90 via-black/50 to-transparent p-2 text-left pointer-events-none z-10">
                    <p className="text-[11px] font-medium text-white truncate">{item.name}</p>
                    <div className="flex justify-between items-center text-[10px] text-slate-300 font-mono tabular-nums">
                      <span>{(item.size / (1024 * 1024)).toFixed(1)} MB</span>
                      {item.subfolder && <span className="opacity-75 truncate max-w-[80px]">{item.subfolder}</span>}
                    </div>
                  </div>
                </div>
              );
            })}
          </div>
        )}
      </div>
    </div>
  );
}
